# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import os

import urlquick
from uuid import uuid4
import base64
import hashlib
import time
from functools import wraps
from distutils.version import LooseVersion
from codequick import Script
from codequick.storage import PersistentDict
from xbmc import executebuiltin
from xbmcgui import Dialog, DialogProgress
from xbmcaddon import Addon
import xbmc
import xbmcvfs
from contextlib import contextmanager
from collections import defaultdict
import socket
import json
import requests
import requests.adapters
import re
import ssl
import urllib.request
from datetime import datetime
from urllib3.util.retry import Retry

ssl._create_default_https_context = ssl._create_unverified_context

# ─── Force IPv4 ──────────────────────────────────────────────────────────────
# On Android TV via mobile hotspot, DNS returns both IPv6 (AAAA) and IPv4 (A)
# records. Android aggressively prefers IPv6, but hotspot doesn't route IPv6
# traffic properly — the TCP SYN goes out but never gets a SYN-ACK, causing
# connections to hang indefinitely. Windows prefers IPv4 which is why it works.
#
# This patches socket.getaddrinfo to only return IPv4 (AF_INET) results,
# forcing all urllib3/requests connections to use IPv4.
import socket as _socket
_original_getaddrinfo = _socket.getaddrinfo

def _ipv4_only_getaddrinfo(host, port, family=0, type=0, proto=0, flags=0):
    return _original_getaddrinfo(host, port, _socket.AF_INET, type, proto, flags)

_socket.getaddrinfo = _ipv4_only_getaddrinfo

from resources.lib.constants import CHANNELS_SRC, DICTIONARY_URL, FEATURED_SRC, VOD_SRC, VOD_CHANNELS_SRC

# ─── Persistent Session ─────────────────────────────────────────────────────
# A shared requests.Session that reuses TLS connections across calls.
# This is critical for Android TV on mobile hotspot where initial TLS
# handshakes can take 15+ seconds. Reusing the session avoids re-handshaking.
#
# The Retry adapter handles transient failures automatically.
_retry_strategy = Retry(
    total=2,                # 2 retries (3 attempts total)
    backoff_factor=1,       # 1s, 2s between retries
    status_forcelist=[429, 500, 502, 503, 504],
    allowed_methods=["GET", "POST", "HEAD"],
)
_adapter = requests.adapters.HTTPAdapter(
    max_retries=_retry_strategy,
    pool_connections=4,     # Keep 4 connection pools
    pool_maxsize=4,         # 4 connections per pool
)

_session = requests.Session()
_session.verify = False
_session.mount("https://", _adapter)
_session.mount("http://", _adapter)

# Suppress InsecureRequestWarning globally
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def get_session():
    """Return the persistent requests.Session with TLS connection reuse.
    Critical for Android TV on mobile hotspot where TLS handshakes are slow."""
    return _session


# Pre-warm the TLS connection to JioTV API on module load (background thread).
# Since reuselanguageinvoker=true, this runs once when utils.py first loads.
# The SSL handshake is done in the background so play() doesn't have to wait.
import threading as _threading
def _prewarm_jiotv_tls():
    try:
        _session.head("https://jiotvapi.media.jio.com/", timeout=(15, 5))
    except Exception:
        pass  # Non-critical; if it fails, the play() call will just do the handshake

_prewarm = _threading.Thread(target=_prewarm_jiotv_tls, daemon=True)
_prewarm.start()


def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(0)
    try:
        s.connect(("8.8.8.8", 80))
        IP = s.getsockname()[0]
    except Exception:
        IP = "127.0.0.1"
    finally:
        s.close()
    return IP


def isLoggedIn(func):
    """
    Decorator to ensure that a valid login is present when calling a method
    """

    @wraps(func)
    def login_wrapper(*args, **kwargs):
        # Safety Shield: Try to restore settings if they seem missing
        restoreSettings()
        
        with PersistentDict("localdb") as db:
            username = db.get("username")
            password = db.get("password")
            headers = db.get("headers")
            exp = db.get("exp", 0)
            
        if headers and exp > time.time():
            try:
                return func(*args, **kwargs)
            except Exception as e:
                # Catch 419 (Authentication Timeout) or 401 (Unauthorized) errors from the server
                if "419" in str(e) or "401" in str(e):
                    Script.log(f"[AUTH] Server returned {e}. Token likely invalidated.", lvl=Script.INFO)
                    with PersistentDict("localdb") as db:
                        db["exp"] = 0  # Force expiry locally
                    Script.notify("Session Expired", "Authentication failed. Please login again.")
                    executebuiltin("RunPlugin(plugin://plugin.kodi.jiotv/resources/lib/auth/login/)")
                    return False
                raise e
        elif username and password:
            login(username, password)
            return func(*args, **kwargs)
        elif headers and exp < time.time():
            Script.notify("Login Error", "Session expired. Please login again")
            executebuiltin(
                "RunPlugin(plugin://plugin.kodi.jiotv/resources/lib/auth/login/)"
            )
            return False
        else:
            Script.notify(
                "Login Error",
                "You need to login with Jio Username and password to use this add-on",
            )
            executebuiltin(
                "RunPlugin(plugin://plugin.kodi.jiotv/resources/lib/auth/login/)"
            )
            return False

    return login_wrapper


def login(username, password, mode="unpw"):
    resp = None
    if mode == "otp":
        mobile = "+91" + username
        otpbody = {
            "number": base64.b64encode(mobile.encode("ascii")).decode("ascii"),
            "otp": password,
            "deviceInfo": {
                "consumptionDeviceName": "unknown sdk_google_atv_x86",
                "info": {
                    "type": "android",
                    "platform": {"name": "generic_x86"},
                    "androidId": str(uuid4()),
                },
            },
        }
        resp = urlquick.post(
            "https://jiotvapi.media.jio.com/userservice/apis/v1/loginotp/verify",
            json=otpbody,
            headers={
                "User-Agent": "okhttp/4.2.2",
                "devicetype": "phone",
                "os": "android",
                "appname": "RJIL_JioTV",
            },
            max_age=-1,
            verify=False,
            raise_for_status=False,
        ).json()
    else:
        body = {
            "identifier": username if "@" in username else "+91" + username,
            "password": password,
            "rememberUser": "T",
            "upgradeAuth": "Y",
            "returnSessionDetails": "T",
            "deviceInfo": {
                "consumptionDeviceName": "ZUK Z1",
                "info": {
                    "type": "android",
                    "platform": {"name": "ham", "version": "8.0.0"},
                    "androidId": str(uuid4()),
                },
            },
        }
        resp = urlquick.post(
            "https://api.jio.com/v3/dip/user/{0}/verify".format(mode),
            json=body,
            headers={
                "User-Agent": "JioTV",
                "x-api-key": "l7xx75e822925f184370b2e25170c5d5820a",
                "Content-Type": "application/json",
            },
            max_age=-1,
            verify=False,
            raise_for_status=False,
        ).json()
    if resp.get("ssoToken", "") != "":
        _CREDS = {
            "ssotoken": resp.get("ssoToken"),
        "userid": resp.get("sessionAttributes", {}).get("user", {}).get("uid"),
        "uniqueid": resp.get("sessionAttributes", {}).get("user", {}).get("unique"),
        "crmid": resp.get("sessionAttributes", {}).get("user", {}).get("subscriberId"),
        "subscriberid": resp.get("sessionAttributes", {}).get("user", {}).get("subscriberId"),
        "authtoken": resp.get("authToken", ""),
        "jtoken": resp.get("jToken", ""),
        "deviceid": resp.get("deviceId", ""),
        }
        headers = {
            "appName": "RJIL_JioTV",
            "deviceId": resp.get("deviceId"),
            "devicetype": "phone",
            "os": "android",
            "osversion": "9",
            "partner": "jiotvvod",
            "user-agent": "plaYtv/7.1.5 (Linux;Android 9) ExoPlayerLib/2.11.7",
            "usergroup": "tvYR7NSNn7rymo3F",
            "versioncode": "396",
            "platform": "ANDROID_PHONE",
            "dm": "ZUK ZUK Z1",
            "authtoken":resp.get("authToken"),
            "ssotoken": resp.get("ssoToken"),
        }
        
        headers.update(_CREDS)
        with PersistentDict("localdb") as db:
            db["headers"] = headers
            # Log the full response to inspect for server-side expiry hints
            Script.log(f"[LOGIN] Response: {resp}", lvl=Script.INFO)
            
            # Set local expiry: 10 days for OTP (matching Jio server), 5 days for Password
            db["exp"] = time.time() + 864000
            if mode == "unpw":
                # Expiry for Password: 5 days (432000 seconds)
                db["exp"] = time.time() + 432000
                db["username"] = username
                db["password"] = password
        
        # Backup after successful login
        backupSettings()
        
        Script.notify("Login Success", "")
        return None
    else:
        Script.log(resp, lvl=Script.INFO)
        msg = resp.get("message", "Unknow Error")
        Script.notify("Login Failed", msg)
        return msg


def sendOTPV2(mobile):
    if "+91" not in mobile:
        mobile = "+91" + mobile
    body = {"number": base64.b64encode(mobile.encode("ascii")).decode("ascii")}
    Script.log(body, lvl=Script.ERROR)
    resp = urlquick.post(
        "https://jiotvapi.media.jio.com/userservice/apis/v1/loginotp/send",
        json=body,
        headers={
            "user-agent": "okhttp/4.2.2",
            "os": "android",
            "host": "jiotvapi.media.jio.com",
            "devicetype": "phone",
            "appname": "RJIL_JioTV",
        },
        max_age=-1,
        verify=False,
        raise_for_status=False,
    )
    if resp.status_code != 204:
        return resp.json().get("errors", [{}])[-1].get("message")
    return None


def logout():
    with PersistentDict("localdb") as db:
        del db["headers"]
    Script.notify("You've been logged out", "")


def getHeaders():
    with PersistentDict("localdb") as db:
        return db.get("headers", False)


def getCachedChannels():
    CACHE_VERSION = "v3.1_hybrid_v2"  # Bump this to force re-fetch
    with PersistentDict("localdb") as db:
        channelList = db.get("channelList", False)
        cacheVersion = db.get("_channelCacheVersion", "")
        # Auto-invalidate stale cache from old v3.0-only code
        if channelList and cacheVersion != CACHE_VERSION:
            Script.log(f"[CHANNELS] Cache version mismatch ({cacheVersion} != {CACHE_VERSION}), refreshing...", lvl=Script.INFO)
            channelList = False
        if not channelList:
            try:
                # Use urlquick with caching to speed up loading
                v14_url = "https://jiotvapi.cdn.jio.com/apis/v1.4/getMobileChannelList/get/?langId=6&devicetype=phone&os=android&usertype=JIO&version=396"
                v31_url = "https://jiotvapi.cdn.jio.com/apis/v3.1/getMobileChannelList/get/?langId=6&os=android&devicetype=phone&usertype=JIO&version=389"
                
                headers = {"User-Agent": "okhttp/4.2.2"}
                
                # Fetch v1.4 channels (primary source - contains Sony, Zee networks)
                v14_channels = urlquick.get(v14_url, headers=headers, max_age=86400, timeout=15).json().get("result", [])

                # Fetch v3.1 channels (secondary source - contains Star, Disney networks) and merge
                try:
                    v31_channels = urlquick.get(v31_url, headers=headers, max_age=86400, timeout=15).json().get("result", [])
                    
                    # Build set of v1.4 channel IDs for fast lookup
                    v14_ids = {ch.get("channel_id") for ch in v14_channels}

                    # Add any v3.1-only channels
                    extra_count = 0
                    for ch in v31_channels:
                        if ch.get("channel_id") not in v14_ids:
                            v14_channels.append(ch)
                            extra_count += 1
                            
                    Script.log(f"[CHANNELS] Merged {extra_count} unique channels from v3.1 into v1.4", lvl=Script.INFO)
                except Exception as e:
                    Script.log(f"[CHANNELS] v3.1 merge failed: {e}", lvl=Script.INFO)

                db["channelList"] = v14_channels
                db["_channelCacheVersion"] = CACHE_VERSION
            except:
                Script.notify("Connection error ", "Retry after sometime")
        return db.get("channelList", False)


def getCachedDictionary():
    CACHE_VERSION = "v2"  # Bump this to force re-fetch
    with PersistentDict("localdb") as db:
        dictionary = db.get("dictionary", False)
        dictVersion = db.get("_dictCacheVersion", "")
        # Auto-invalidate stale cache
        if dictionary and dictVersion != CACHE_VERSION:
            Script.log(f"[DICT] Cache version mismatch, refreshing...", lvl=Script.INFO)
            dictionary = False
        if not dictionary:
            try:
                r = urlquick.get(
                    "https://jiotvapi.cdn.jio.com/apis/v1.3/dictionary/dictionary?langId=6",
                    headers={"User-Agent": "okhttp/4.2.2"},
                    max_age=604800, # 7 days
                    timeout=15
                )
                import json
                db["dictionary"] = json.loads(r.content.decode('utf-8-sig'))
                db["_dictCacheVersion"] = CACHE_VERSION
            except:
                Script.notify(
                    "dictionary url -Connection error ", "Retry after sometime"
                )
        return db.get("dictionary", False)


def getFeatured():
    try:
        resp = urlquick.get(
            FEATURED_SRC,
            verify=False,
            headers={
                "usergroup": "tvYR7NSNn7rymo3F",
                "os": "android",
                "devicetype": "phone",
                "versionCode": "396",
            },
            max_age=3600, # 1 hour
            timeout=15
        ).json()
        return resp.get("featuredNewData", [])
    except:
        # Script.notify("Connection error ", "Retry after sometime")
        pass


def getVODContent():
    """
    Get VOD-like content from available sources.
    Since dedicated VOD endpoints don't exist, extract VOD-like content from featured data.
    """
    try:
        # Get featured content which actually works
        featured_data = getFeatured()
        
        # Check if featured_data is valid
        if not featured_data:
            Script.log("No featured data available for VOD extraction", lvl=Script.WARNING)
            return []
        
        vod_like_content = []
        
        for category in featured_data:
            if isinstance(category, dict) and "data" in category:
                for item in category.get("data", []):
                    # Extract VOD-like content: not live, not future, has poster
                    show_status = item.get("showStatus", "")
                    has_poster = item.get("episodePoster", "")
                    
                    if (show_status not in ["Now", "future"] and 
                        has_poster and 
                        item.get("description", "")):
                        
                        # Mark as VOD content
                        item["_isVOD"] = True
                        item["_vodCategory"] = category.get("name", "General")
                        vod_like_content.append(item)
        
        if vod_like_content:
            Script.log(f"Found {len(vod_like_content)} VOD-like items from featured content", lvl=Script.INFO)
            return vod_like_content
        else:
            Script.log("No VOD-like content found in featured data", lvl=Script.INFO)
            return []
            
    except Exception as e:
        Script.log(f"Failed to extract VOD from featured: {e}", lvl=Script.ERROR)
        return []


def getVODChannels():
    """
    Get channels that support VOD/catchup content.
    Determined simply by the isCatchupAvailable flag from the API.
    """
    try:
        all_channels = getCachedChannels()
        vod_channels = []
        
        for channel in all_channels:
            has_catchup = channel.get("isCatchupAvailable", False)
            
            # Include all channels that have catchup (VOD) available
            if has_catchup:
                channel["_isVODChannel"] = True
                vod_channels.append(channel)
        
        if vod_channels:
            # Sort by channel name initially
            vod_channels.sort(key=lambda x: str(x.get("channel_name", "")).lower())
            Script.log(f"Found {len(vod_channels)} VOD-capable channels from {len(all_channels)} total channels", lvl=Script.INFO)
            return vod_channels
        else:
            Script.log("No VOD-capable channels found", lvl=Script.INFO)
            return []
            
    except Exception as e:
        Script.log(f"Failed to get VOD channels: {e}", lvl=Script.ERROR)
        return []


def getChannelVODContent(channel_id, offset_days=0):
    """
    Get VOD-like content for a specific channel using catchup EPG data.
    offset_days: 0 for most recent, 1 for yesterday, etc.
    """
    try:
        headers = getHeaders()
        if not headers:
            Script.log("No headers available for channel VOD", lvl=Script.ERROR)
            return []
        
        # Get EPG/catchup data for the channel with offset
        # Use negative offset to go back in time
        epg_url = f"https://jiotvapi.cdn.jio.com/apis/v1.3/getepg/get?offset={-offset_days}&channel_id={channel_id}&langId=6"
        
        headers = dict(headers)
        headers["User-Agent"] = "okhttp/4.2.2"
        resp = urlquick.get(epg_url, headers=headers, verify=False, max_age=1800, timeout=15)
        epg_data = resp.json()
        
        vod_content = []
        current_time = int(time.time() * 1000)
        
        for show in epg_data.get("epg", []):
            # Include past shows with catchup availability (VOD-like)
            # Some channels like Brio TV or Cartoon Network wrongly have stbCatchupAvailable=False
            if (show.get("startEpoch", 0) < current_time):
                
                # Mark as channel VOD content with offset info
                show["_isChannelVOD"] = True
                show["_channelId"] = channel_id
                show["_vodType"] = "catchup"
                show["_offsetDays"] = offset_days
                
                vod_content.append(show)
        
        # Sort by start time in descending order (most recent first)
        vod_content.sort(key=lambda x: x.get("startEpoch", 0), reverse=True)
        
        if vod_content:
            Script.log(f"Found {len(vod_content)} VOD items for channel {channel_id} (offset: {offset_days} days)", lvl=Script.INFO)
            return vod_content
        else:
            Script.log(f"No VOD content found for channel {channel_id} (offset: {offset_days} days)", lvl=Script.INFO)
            return []
            
    except Exception as e:
        Script.log(f"Failed to get channel VOD content: {e}", lvl=Script.ERROR)
        return []


def cleanLocalCache():
    try:
        with PersistentDict("localdb") as db:
            del db["channelList"]
            del db["dictionary"]
    except:
        Script.notify("Cache", "Cleaned")


def backupSettings():
    """Backup critical user settings to a persistent file to prevent loss during upgrades."""
    try:
        # Saving directly to Kodi's root userdata folder means the backup survives an addon uninstallation
        backup_file = xbmcvfs.translatePath("special://userdata/.jiotv_backup.json")
        
        # Collect critical data
        mobile = Addon().getSetting("mobile")
        with PersistentDict("localdb") as db:
            headers = db.get("headers")
            username = db.get("username")
            password = db.get("password")
            
        data = {
            "mobile": mobile,
            "headers": headers,
            "username": username,
            "password": password,
            "timestamp": time.time()
        }
        
        with open(backup_file, "w") as f:
            json.dump(data, f)
            
        Script.log("[SAFETY] User settings backed up successfully", lvl=Script.INFO)
    except Exception as e:
        Script.log(f"[SAFETY] Failed to backup settings: {e}", lvl=Script.ERROR)


def restoreSettings():
    """Restore critical user settings from persistent backup if they are missing."""
    try:
        addon = Addon()
        current_mobile = addon.getSetting("mobile")
        
        with PersistentDict("localdb") as db:
            has_headers = "headers" in db
            
        # If we have both, no need to restore
        if current_mobile and has_headers:
            return
            
        backup_file = xbmcvfs.translatePath("special://userdata/.jiotv_backup.json")
        
        if not os.path.exists(backup_file):
            return
            
        with open(backup_file, "r") as f:
            data = json.load(f)
            
        restored = False
        
        # Restore mobile if missing
        if not current_mobile and data.get("mobile"):
            addon.setSetting("mobile", data["mobile"])
            restored = True
            
        # Restore headers/credentials if missing
        with PersistentDict("localdb") as db:
            if not "headers" in db and data.get("headers"):
                db["headers"] = data["headers"]
                if data.get("username"): db["username"] = data["username"]
                if data.get("password"): db["password"] = data["password"]
                restored = True
                
        if restored:
            Script.log("[SAFETY] User settings restored from persistent backup", lvl=Script.INFO)
            Script.notify("JioTV", "Settings restored from backup")
            
    except Exception as e:
        Script.log(f"[SAFETY] Failed to restore settings: {e}", lvl=Script.ERROR)


def backupFavourites():
    src = xbmcvfs.translatePath("special://userdata/favourites.xml")
    dest = xbmcvfs.translatePath("special://userdata/jiotv_favourites_backup.xml")
    if xbmcvfs.exists(src):
        try:
            if xbmcvfs.exists(dest):
                xbmcvfs.delete(dest)
            xbmcvfs.copy(src, dest)
            Script.notify("Favourites", "Favourites backed up successfully")
        except Exception as e:
            Script.log(f"Failed to backup favourites: {e}", lvl=Script.ERROR)
            Script.notify("Error", "Failed to backup favourites")
    else:
        Script.notify("Favourites Error", "No favourites.xml found to backup")

def restoreFavourites():
    src = xbmcvfs.translatePath("special://userdata/jiotv_favourites_backup.xml")
    dest = xbmcvfs.translatePath("special://userdata/favourites.xml")
    if xbmcvfs.exists(src):
        try:
            if xbmcvfs.exists(dest):
                xbmcvfs.delete(dest)
            xbmcvfs.copy(src, dest)
            Script.notify("Favourites", "Favourites restored. Restart Kodi to apply.")
        except Exception as e:
            Script.log(f"Failed to restore favourites: {e}", lvl=Script.ERROR)
            Script.notify("Error", "Failed to restore favourites")
    else:
        Script.notify("Favourites Error", "No backup found to restore")

def shareFavourites():
    src = xbmcvfs.translatePath("special://userdata/favourites.xml")
    if not xbmcvfs.exists(src):
        Script.notify("Favourites Error", "No favourites.xml found to share")
        return
        
    dialog = Dialog()
    dest_dir = dialog.browse(3, "Select folder to export favourites", "files")
    if dest_dir:
        # Construct path keeping Kodi VFS compatibility in mind
        if not dest_dir.endswith('/') and not dest_dir.endswith('\\'):
            dest_dir += '/'
        dest = dest_dir + "favourites.xml"
        try:
            if xbmcvfs.exists(dest):
                xbmcvfs.delete(dest)
            xbmcvfs.copy(src, dest)
            Script.notify("Favourites", "Favourites exported successfully")
        except Exception as e:
            Script.log(f"Failed to export favourites: {e}", lvl=Script.ERROR)
            Script.notify("Error", "Failed to export favourites")

def importFavourites():
    dialog = Dialog()
    src = dialog.browse(1, "Select favourites file to import", "files", ".xml")
    if src:
        dest = xbmcvfs.translatePath("special://userdata/favourites.xml")
        try:
            if xbmcvfs.exists(dest):
                xbmcvfs.delete(dest)
            xbmcvfs.copy(src, dest)
            Script.notify("Favourites", "Favourites imported. Restart Kodi to apply.")
        except Exception as e:
            Script.log(f"Failed to import favourites: {e}", lvl=Script.ERROR)
            Script.notify("Error", "Failed to import favourites")


def getChannelHeaders():
    headers = getHeaders()
    return {
        "ssoToken": headers["ssotoken"],
        "userId": headers["userid"],
        "uniqueId": str(headers["uniqueid"]),
        "crmid": str(headers["crmid"]),
        "user-agent": "plaYtv/7.1.5 (Linux;Android 9) ExoPlayerLib/2.11.7",
        "deviceid": headers["deviceId"],
        "devicetype": "phone",
        "os": "B2G",
        "osversion": "2.5",
        "versioncode": "353",
    }


def getSonyHeaders(channel_id=None, languageId=None):
    sony=getHeaders()
    return {
        "Host": "jiotvapi.media.jio.com",
            "Appkey": "NzNiMDhlYzQyNjJm",
            "Devicetype": "phone",
            "Os": "android",
            "Deviceid": sony["deviceId"],
            "Osversion": "13",
            "Dm": "Google Pixel 5",
            "Uniqueid": sony["deviceId"],
            "Usergroup": "tvYR7NSNn7rymo3F",
            "Languageid": languageId if languageId else "6",
            "Userid": sony["userid"],
            "Sid": "892898ba-f9de-4572-b6c2-e717b0ad",
            "Crmid": sony["subscriberid"],
            "Isott": "false",
            "Channel_id": str(channel_id) if channel_id else "471",
            "Langid": languageId if languageId else "",
            "Camid": "",
            "ssoToken": sony["ssotoken"],
            "Accesstoken": sony["authtoken"],
            "Subscriberid": sony["subscriberid"],
            "analyticsId": sony["deviceId"],
            "Lbcookie": "1",
            "Versioncode": "389",
            "Content-Type": "application/x-www-form-urlencoded",
        # "Content-Length": "110",
            "Accept-Encoding": "gzip, deflate, br",
            "user-agent": "okhttp/4.2.2",
            "Connection": "keep-alive",
    }

# Zee5 headers

def getZeeHeaders(host=None):
    return {
    "Host": host,
    "accept": "*/*",
    "accept-encoding": "gzip, deflate, br, zstd",
    "accept-language": "en-US,en;q=0.9",
    "origin": "https://www.zee5.com",
    "priority": "u=1, i",
    "referer": "https://www.zee5.com/",
    "sec-ch-ua": '"Google Chrome";v="141", "Not?A_Brand";v="8", "Chromium";v="141"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36"
}
    
def zeeCookie(zee_channelid=None):
    url = "https://spapi.zee5.com/singlePlayback/getDetails/secure"
    params = {
        "channel_id": zee_channelid,
        "device_id": "90abf228-06b1-42ae-aa65-4979df5bcef6",
        "platform_name": "desktop_web",
        "translation": "en",
        "user_language": "te",
        "country": "IN",
        "state": "TS",
        "app_version": "4.26.1",
        "user_type": "guest",
        "check_parental_control": "false",
        "ppid": "90abf228-06b1-42ae-aa65-4979df5bcef6",
        "version": "12"
    }

    json_data = {
        "x-access-token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwbGF0Zm9ybV9jb2RlIjoiV2ViQCQhdDM4NzEyIiwiaXNzdWVkQXQiOiIyMDI1LTEwLTIyVDAzOjQ4OjA1LjAyOVoiLCJwcm9kdWN0X2NvZGUiOiJ6ZWU1QDk3NSIsInR0bCI6ODY0MDAwMDAsImlhdCI6MTc2MTEwNDg4NX0.8HnOYX7GmvGGWWiPfYPlvJk55Bzmjd1qEQIx6ueOnCs",
        "X-Z5-Guest-Token": "90abf228-06b1-42ae-aa65-4979df5bcef6",
        "x-dd-token": "eyJzY2hlbWFfdmVyc2lvbiI6IjEiLCJvc19uYW1lIjoiTi9BIiwib3NfdmVyc2lvbiI6Ik4vQSIsInBsYXRmb3JtX25hbWUiOiJDaHJvbWUiLCJwbGF0Zm9ybV92ZXJzaW9uIjoiMTA0IiwiZGV2aWNlX25hbWUiOiIiLCJhcHBfbmFtZSI6IldlYiIsImFwcF92ZXJzaW9uIjoiMi41Mi4zMSIsInBsYXllcl9jYXBhYmlsaXRpZXMiOnsiYXVkaW9fY2hhbm5lbCI6WyJTVEVSRU8iXSwidmlkZW9fY29kZWMiOlsiSDI2NCJdLCJjb250YWluZXIiOlsiTVA0IiwiVFMiXSwicGFja2FnZSI6WyJEQVNIIiwiSExTIl0sInJlc29sdXRpb24iOlsiMjQwcCIsIlNEIiwiSEQiLCJGSEQiXSwiZHluYW1pY19yYW5nZSI6WyJTRFIiXX0sInNlY3VyaXR5X2NhcGFiaWxpdGllcyI6eyJlbmNyeXB0aW9uIjpbIldJREVWSU5FX0FFU19DVFIiXSwid2lkZXZpbmVfc2VjdXJpdHlfbGV2ZWwiOlsiTDMiXSwiaGRjcF92ZXJzaW9uIjpbIkhEQ1BfVjEiLCJIRENQX1YyIiwiSERDUF9WMl8xIiwiSERDUF9WMl8yIl19fQ=="
    }

    headers = {
        "accept": "application/json",
        "accept-encoding": "gzip, deflate, br",
        "accept-language": "en-US,en;q=0.9",
        "origin": "https://www.zee5.com",
        "referer": "https://www.zee5.com/",
        "content-type": "application/json",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36",
    }

    try:
        resp = requests.post(url, headers=headers, params=params, json=json_data, timeout=15)
        if resp.status_code == 403:
            return None
        result = resp.json()
    except Exception as e:
        return None

    m3u8_response = result.get("keyOsDetails", {}).get("video_token")
    if not m3u8_response:
        return None

    cookie = "?" + m3u8_response.split("?", 1)[1] if "?" in m3u8_response else ""

    return cookie
    
        


def getChannelHeadersWithHost():
    return {
        "deviceType": "phone",
        "host": "tv.media.jio.com",
        "os": "B2G",
        "versioncode": "396",
        "Conetent-Type": "application/json",
    }


def getTokenParams():
    def magic(x):
        return (
            base64.b64encode(hashlib.md5(x.encode()).digest())
            .decode()
            .replace("=", "")
            .replace("+", "-")
            .replace("/", "_")
            .replace("\r", "")
            .replace("\n", "")
        )

    pxe = str(int(time.time() + (3600 * 9.2)))
    jct = magic("cutibeau2ic9p-O_v1qIyd6E-rf8_gEOQ" + pxe)
    return {"jct": jct, "pxe": pxe, "st": "9p-O_v1qIyd6E-rf8_gEOQ"}


def check_addon(addonid, minVersion=False):
    """Checks if selected add-on is installed."""
    try:
        curVersion = Script.get_info("version", addonid)
        # Script.notify("version" , curVersion)
        if minVersion and LooseVersion(curVersion) < LooseVersion(minVersion):
            Script.log(
                "{addon} {curVersion} doesn't setisfy required version {minVersion}.".format(
                    addon=addonid, curVersion=curVersion, minVersion=minVersion
                )
            )
            Dialog().ok(
                "Error",
                "{minVersion} version of {addon} is required to play this content.".format(
                    addon=addonid, minVersion=minVersion
                ),
            )
            return False
        return True
    except RuntimeError:
        Script.log("{addon} is not installed.".format(addon=addonid))
        if not _install_addon(addonid):
            # inputstream is missing on system
            Dialog().ok(
                "Error",
                "[B]{addon}[/B] is missing on your Kodi install. This add-on is required to play this content.".format(
                    addon=addonid
                ),
            )
            return False
        return True


def _install_addon(addonid):
    """Install addon."""
    try:
        # See if there's an installed repo that has it
        executebuiltin("InstallAddon({})".format(addonid), wait=True)

        # Check if add-on exists!
        version = Script.get_info("version", addonid)

        Script.log(
            "{addon} {version} add-on installed from repo.".format(
                addon=addonid, version=version
            )
        )
        return True
    except RuntimeError:
        Script.log("{addon} add-on not installed.".format(addon=addonid))
        return False


def quality_to_enum(quality_str, arr_len):
    """Converts quality into a numeric value. Max clips to fall within valid bounds."""
    mapping = {
        "Best": arr_len - 1,
        "High": max(arr_len - 2, arr_len - 3),
        "Medium+": max(arr_len - 3, arr_len - 4),
        "Medium": max(2, arr_len - 3),
        "Low": min(2, arr_len - 3),
        "Lower": 1,
        "Lowest": 0,
    }
    if quality_str in mapping:
        return min(mapping[quality_str], arr_len - 1)
    return 0


_signals = defaultdict(list)
_skip = defaultdict(int)


def emit(signal, *args, **kwargs):
    if _skip[signal] > 0:
        _skip[signal] -= 1
        return

    for f in _signals.get(signal, []):
        f(*args, **kwargs)


class Monitor(xbmc.Monitor):
    def onSettingsChanged(self):
        emit("on_settings_changed")


monitor = Monitor()


def kodi_rpc(method, params=None, raise_on_error=False):
    try:
        payload = {"jsonrpc": "2.0", "id": 1}
        payload.update({"method": method})
        if params:
            payload["params"] = params

        data = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        if "error" in data:
            raise Exception(
                'Kodi RPC "{} {}" returned Error: "{}"'.format(
                    method, params or "", data["error"].get("message")
                )
            )

        return data["result"]
    except Exception as e:
        if raise_on_error:
            raise
        else:
            return {}


def set_kodi_setting(key, value):
    return kodi_rpc("Settings.SetSettingValue", {"setting": key, "value": value})


def same_file(path_a, path_b):
    if path_a.lower().strip() == path_b.lower().strip():
        return True

    stat_a = os.stat(path_a) if os.path.isfile(path_a) else None
    if not stat_a:
        return False

    stat_b = os.stat(path_b) if os.path.isfile(path_b) else None
    if not stat_b:
        return False

    return (
        (stat_a.st_dev == stat_b.st_dev)
        and (stat_a.st_ino == stat_b.st_ino)
        and (stat_a.st_mtime == stat_b.st_mtime)
    )


def safe_copy(src, dst, del_src=False):
    src = xbmcvfs.translatePath(src)
    dst = xbmcvfs.translatePath(dst)

    if not xbmcvfs.exists(src) or same_file(src, dst):
        return

    if xbmcvfs.exists(dst):
        if xbmcvfs.delete(dst):
            Script.log("Deleted: {}".format(dst))
        else:
            Script.log("Failed to delete: {}".format(dst))

    if xbmcvfs.copy(src, dst):
        Script.log("Copied: {} > {}".format(src, dst))
    else:
        Script.log("Failed to copy: {} > {}".format(src, dst))

    if del_src:
        xbmcvfs.delete(src)


@contextmanager
def busy():
    xbmc.executebuiltin("ActivateWindow(busydialognocancel)")
    try:
        yield
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")


def _setup(m3uPath, epgUrl):
    pDialog = DialogProgress()
    pDialog.create("PVR Setup in progress")
    ADDON_ID = "pvr.iptvsimple"
    addon = Addon(ADDON_ID)
    ADDON_NAME = addon.getAddonInfo("name")
    addon_path = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    instance_filepath = os.path.join(addon_path, "instance-settings-91.xml")

    kodi_rpc("Addons.SetAddonEnabled", {"addonid": ADDON_ID, "enabled": False})
    pDialog.update(10)

    # newer PVR Simple uses instance settings that can't yet be set via python api
    # so do a workaround where we leverage the migration when no instance settings found
    if LooseVersion(addon.getAddonInfo("version")) >= LooseVersion("20.8.0"):
        xbmcvfs.delete(instance_filepath)

        for file in os.listdir(addon_path):
            if file.startswith("instance-settings-") and file.endswith(".xml"):
                file_path = os.path.join(addon_path, file)
                with open(file_path) as f:
                    data = f.read()
                # ensure no duplication in other instances
                if (
                    'id="m3uPath">{}</setting>'.format(m3uPath) in data
                    or 'id="epgUrl">{}</setting>'.format(epgUrl) in data
                ):
                    xbmcvfs.delete(os.path.join(addon_path, file_path))
                else:
                    safe_copy(file_path, file_path + ".bu", del_src=True)
        pDialog.update(25)
        kodi_rpc("Addons.SetAddonEnabled", {"addonid": ADDON_ID, "enabled": True})
        # wait for migration to occur
        while not os.path.exists(os.path.join(addon_path, "instance-settings-1.xml")):
            monitor.waitForAbort(1)
        kodi_rpc("Addons.SetAddonEnabled", {"addonid": ADDON_ID, "enabled": False})
        monitor.waitForAbort(1)

        safe_copy(
            os.path.join(addon_path, "instance-settings-1.xml"),
            instance_filepath,
            del_src=True,
        )
        pDialog.update(35)
        with open(instance_filepath, "r") as f:
            data = f.read()
        with open(instance_filepath, "w") as f:
            f.write(data.replace("Migrated Add-on Config", ADDON_NAME))
        pDialog.update(50)
        for file in os.listdir(addon_path):
            if file.endswith(".bu"):
                safe_copy(
                    os.path.join(addon_path, file),
                    os.path.join(addon_path, file[:-3]),
                    del_src=True,
                )
        kodi_rpc("Addons.SetAddonEnabled", {"addonid": ADDON_ID, "enabled": True})
        pDialog.update(70)
    else:
        kodi_rpc("Addons.SetAddonEnabled", {"addonid": ADDON_ID, "enabled": True})
        pDialog.update(70)

    set_kodi_setting("epg.futuredaystodisplay", 7)
    #  set_kodi_setting('epg.ignoredbforclient', True)
    set_kodi_setting("pvrmanager.syncchannelgroups", True)
    set_kodi_setting("pvrmanager.preselectplayingchannel", True)
    set_kodi_setting("pvrmanager.backendchannelorder", True)
    set_kodi_setting("pvrmanager.usebackendchannelnumbers", True)
    pDialog.update(100)
    pDialog.close()
    Script.notify("IPTV setup", "Epg and playlist updated")

    return True
